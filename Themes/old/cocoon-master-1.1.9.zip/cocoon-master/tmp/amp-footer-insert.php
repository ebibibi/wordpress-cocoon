<?php //AMP Lightboxが有効な時
if(is_amp_image_zoom_effect_lightbox()): ?>
  <amp-image-lightbox id="amp-lightbox" layout="nodisplay"></amp-image-lightbox>
<?php endif; ?>
