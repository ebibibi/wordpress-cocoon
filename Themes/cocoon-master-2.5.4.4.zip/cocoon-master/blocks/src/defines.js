/**
 * Cocoon Blocks
 * @author: yhira
 * @link: https://wp-cocoon.com/
 * @license: http://www.gnu.org/licenses/gpl-2.0.html GPL v2 or later
 */

export const THEME_NAME = 'cocoon';
export const BLOCK_CLASS = ' block-box';