<?php //ブロックエディターカラーパレットの色スタイル
/**
 * Cocoon WordPress Theme
 * @author: yhira
 * @link: https://wp-cocoon.com/
 * @license: http://www.gnu.org/licenses/gpl-2.0.html GPL v2 or later
 */
// require_once('../../../../../wp-load.php');
// $color_sets = get_cocoon_editor_color_palette_colors();
// $default_colors = array(get_editor_key_color(), '#e60033', '#e95295', '#884898', '#55295b', '#1e50a2', '#0095d9', '#2ca9e1', '#00a3af', '#007b43', '#3eb370', '#8bc34a', '#c3d825', '#ffd900', '#ffc107', '#f39800', '#ea5506', '#954e2a', '#949495', '#333333', '#ffffff');
// foreach ($color_sets as $color_set) {
//   $color = $color_set['color'];
//   //デフォルトで定義されていない色があった場合
//   if (!in_array($color, $default_colors)) {
//    //_v($color);
//    $name = 'color--'.str_replace('#', '', $color);
//     generate_block_editor_color_style(null, $name, $color);
//   }
// }
