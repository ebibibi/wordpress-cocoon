// Lithuanian
fb.data.strings = [
"lt",
"Baigti (key: Esc)",
"Ankstesnis (key: \u2190)",
"Sekantis (key: \u2192)",
"Groti (key: spacebar)",
"Pauz\u0117 (key: spacebar)",
"Didinti (key: Page Up/Down)",
"Paveiksl\u0117lis %1 i\u0161 %2",
"Puslapis %1 i\u0161 %2",
"(%1 i\u0161 %2)",
"Informacija...",
"Spausdinti...",
"Atidaryti naujame lange",
"Laikin\u0105 lang\u0105 turinys yra u\u017eblokuotas naudojant \u0161i\u0105 nar\u0161ykl\u0119."
];
