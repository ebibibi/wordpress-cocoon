// German
fb.data.strings = [
"de",
"Schlie\u00dfen (Taste: Esc)",
"Zur\u00fcck (Taste: \u2190)",
"Weiter (Taste: \u2192)",
"Wiedergabe (Taste: Leertaste)",
"Anhalten (Taste: Leertaste)",
"Skalieren (Taste: Page Up/Down)",
"Bild %1 von %2",
"Seite %1 von %2",
"(%1 von %2)",
"Info...",
"Drucken...",
"In neuem Fenster \u00f6ffnen",
"Pop-up Inhalt wurde von diesem Browser ist blockiert."
];
