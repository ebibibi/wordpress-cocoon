// Bosnian
fb.data.strings = [
"bs",
"Zatvori (tipka: Esc)",
"Prethodna (tipka: \u2190)",
"Slijede\u0107a (tipka: \u2192)",
"Pokreni (tipka: razmak)",
"Pauza (tipka: razmak)",
"Zumiraj (tipka: Page Up/Down)",
"Slika %1 od %2",
"Strana %1 od %2",
"(%1 od %2)",
"Info...",
"Ispi\u0161i...",
"Otvorite u novom prozoru",
"Pop-up content is blocked by this browser."
];
