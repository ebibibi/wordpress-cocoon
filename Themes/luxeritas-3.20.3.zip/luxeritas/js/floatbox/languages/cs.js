// Czech
fb.data.strings = [
"cs",
"Zav\u0159\u00edt (kl\u00e1vesa: Esc)",
"P\u0159edchoz\u00ed (kl\u00e1vesa: \u2190)",
"Dal\u0161\u00ed (kl\u00e1vesa: \u2192)",
"P\u0159ehr\u00e1t (kl\u00e1vesa: mezern\u00edk)",
"Pauza (kl\u00e1vesa: mezern\u00edk)",
"Zm\u011bna velikosti (kl\u00e1vesa: Page Up/Down)",
"Obr\u00e1zek %1 z %2",
"Strana %1 z %2",
"(%1 z %2)",
"Info...",
"Tisk...",
"Otev\u0159\u00edt v nov\u00e9m okn\u011b",
"Pop-up obsah byl zablokov\u00e1n spole\u010dnost\u00ed tohoto prohl\u00ed\u017ee\u010de."
];
