// French
fb.data.strings = [
"fr",
"Fermer (clav: Esc)",
"Pr\u00e9c\u00e9dent (clav: \u2190)",
"Suivant (clav: \u2192)",
"Jouer (clav: barre d'espace)",
"Pause (clav: barre d'espace)",
"Redimensionner (clav: Page Up/Down)",
"Image %1 de %2",
"Page %1 de %2",
"(%1 de %2)",
"L'info...",
"Imprimer...",
"Ouvrir dans une nouvelle fen\u00eatre",
"Pop-up contenu est bloqu\u00e9 par ce navigateur."
];
