// Portuguese
fb.data.strings = [
"pt",
"Fechar (tecla: Esc)",
"Anterior (tecla: \u2190)",
"Sequinte (tecla: \u2192)",
"Iniciar (tecla: espa\u00e7o)",
"Pausa (tecla: espa\u00e7o)",
"Ajustar (tecla: Page Up/Down)",
"Imagem %1 de %2",
"P\u00e1gina %1 de %2",
"(%1 de %2)",
"Info...",
"Imprimir...",
"Abrir em uma nova janela",
"Pop-up conte\u00fado \u00e9 bloqueado neste navegador."
];
