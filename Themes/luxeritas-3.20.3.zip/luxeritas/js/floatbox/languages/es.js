// Spanish
fb.data.strings = [
"es",
"Salir (teclado: Esc)",
"Anterior (teclado: \u2190)",
"Posterior (teclado: \u2192)",
"Activar (teclado: barra espaciadora)",
"Pausa (teclado: barra espaciadora)",
"Tama\u00f1o (teclado: Page Up/Down)",
"Imagen %1 de %2",
"P\u00e1gina %1 de %2",
"(%1 de %2)",
"Info...",
"Imprimir...",
"Abrir en una nueva ventana",
"Pop-up contenido ha sido bloqueado por este navegador."
];
