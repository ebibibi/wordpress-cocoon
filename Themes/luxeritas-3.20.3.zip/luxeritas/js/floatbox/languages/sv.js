// Swedish
fb.data.strings = [
"sv",
"St\u00e4ng (Tangent: Esc)",
"F\u00f6reg\u00e5ende (Tangent: \u2190)",
"N\u00e4sta (Tangent: \u2192)",
"Spela upp (Tangent: Mellanslag)",
"Pausa (Tangent: Mellanslag)",
"Zooma (Tangent: Page Up/Down)",
"Bild %1 av %2",
"Sida %1 av %2",
"(%1 av %2)",
"Info...",
"Skriv ut...",
"\u00d6ppna i nytt f\u00f6nster",
"Pop-up inneh\u00e5ll blockeras av den h\u00e4r webbl\u00e4saren."
];
