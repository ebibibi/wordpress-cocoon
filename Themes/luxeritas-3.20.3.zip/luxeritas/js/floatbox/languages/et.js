// Estonian
fb.data.strings = [
"et",
"L\u00f5pp (tastatuur: Esc)",
"Eelmine (tastatuur: \u2190)",
"J\u00e4rgmine (tastatuur: \u2192)",
"Esita (tastatuur: t\u00fchikuklahvi)",
"Paus (tastatuur: t\u00fchikuklahvi)",
"Muuda suurust (tastatuur: Page Up/Down)",
"Pilt %1 kohta %2",
"Lehek\u00fclg %1 kohta %2",
"(%1 kohta %2)",
"Info...",
"Prindi...",
"Ava uues aknas",
"Pop-up sisu on blokeeritud selles brauseris."
];
