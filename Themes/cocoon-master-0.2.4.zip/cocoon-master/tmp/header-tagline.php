<?php //キャッチフレーズ ?>
<?php if (is_tagline_visible()): ?>
<div class="tagline" itemprop="alternativeHeadline"><?php bloginfo('description') ?></div>
<?php endif ?>