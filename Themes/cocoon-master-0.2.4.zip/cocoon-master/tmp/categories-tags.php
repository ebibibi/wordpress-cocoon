<div class="entry-categories-tags<?php echo get_additional_categories_tags_area_classes(); ?>">
  <div class="entry-categories"><?php the_category_links() ?></div>
  <div class="entry-tags"><?php the_tag_links() ?></div>
</div>