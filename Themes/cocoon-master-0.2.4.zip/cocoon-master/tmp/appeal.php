<?php //アピールエリアテンプレート ?>
<?php //アピールエリアを表示するか
if (is_appeal_area_visible() && !is_amp()): ?>
<div id="appeal" class="appeal<?php echo get_additional_appeal_area_classes(); ?>">
  <div id="appeal-in" class="appeal-in wrap">
    <div class="appeal-content">
      <?php //タイトルが存在するか
      if (get_appeal_area_title()): ?>
      <div class="appeal-title">
        <?php echo get_appeal_area_title(); ?>
      </div>
      <?php endif ?>
      <?php //メッセージが存在するか
      if (get_appeal_area_message()): ?>
      <div class="appeal-message">
        <?php echo wpautop(get_appeal_area_message()); ?>
      </div>
      <?php endif ?>
      <?php if (get_appeal_area_button_message() && get_appeal_area_button_url()): ?>
      <a href="<?php echo get_appeal_area_button_url(); ?>" class="appeal-button">
        <?php echo get_appeal_area_button_message(); ?>
      </a>
      <?php endif ?>
    </div>
  </div>
</div>
<?php endif ?>