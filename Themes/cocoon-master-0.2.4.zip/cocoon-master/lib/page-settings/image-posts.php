<?php //画像設定をデータベースに保存

//アイキャッチの表示
update_theme_option(OP_EYECATCH_VISIBLE);

//Auto Post Thumbnail
update_theme_option(OP_AUTO_POST_THUMBNAIL_ENABLE);

//画像の枠線効果
update_theme_option(OP_IMAGE_WRAP_EFFECT);

//画像の拡大効果
update_theme_option(OP_IMAGE_ZOOM_EFFECT);