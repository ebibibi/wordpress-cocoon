<?php //AMP設定用関数

//AMPの有効化
update_theme_option(OP_AMP_ENABLE);

//AMPロゴ
update_theme_option(OP_AMP_LOGO_IMAGE_URL);

//AMPバリデーションツール
update_theme_option(OP_AMP_VALIDATOR);

//AMP除外カテゴリ
update_theme_option(OP_AMP_EXCLUDE_CATEGORY_IDS);


