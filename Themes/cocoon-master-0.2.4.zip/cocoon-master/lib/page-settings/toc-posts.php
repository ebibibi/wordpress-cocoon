<?php //目次設定をデータベースに保存
//目次の表示
update_theme_option(OP_TOC_VISIBLE);

//目次タイトル
update_theme_option(OP_TOC_TITLE);

//目次を表示する深さ
update_theme_option(OP_TOC_DEPTH);

//目次の数字の表示
update_theme_option(OP_TOC_NUMBER_TYPE);

//目次を広告の手前に表示
update_theme_option(OP_TOC_BEFORE_ADS);