<?php //コメント設定をデータベースに保存

//コメントの見出し
update_theme_option(OP_COMMENT_HEADING);

//コメントのサブ見出し
update_theme_option(OP_COMMENT_SUB_HEADING);

//コメント入力欄の見出し
update_theme_option(OP_COMMENT_FORM_HEADING);

//ウェブサイト入力欄表示
update_theme_option(OP_COMMENT_WEBSITE_VISIBLE);

//コメント送信ボタンのラベル
update_theme_option(OP_COMMENT_SUBMIT_LABEL);