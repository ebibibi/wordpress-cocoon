<?php //タイトル設定をデータベースに保存

//内部ブログカードが有効
update_theme_option(OP_INTERNAL_BLOGCARD_ENABLE);

//内部ブログカードのサムネイル設定
update_theme_option(OP_INTERNAL_BLOGCARD_THUMBNAIL_STYLE);

//内部ブログカードを新しいタブで開くか
update_theme_option(OP_INTERNAL_BLOGCARD_TARGET_BLANK);