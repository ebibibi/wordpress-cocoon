<?php //アピールエリア設定をデータベースに保存

//カルーセルの表示
update_theme_option(OP_CAROUSEL_DISPLAY_TYPE);

//カルーセルに表示するカテゴリID
update_theme_option(OP_CAROUSEL_CATEGORY_IDS);

//カルーセルオートプレイ
update_theme_option(OP_CAROUSEL_AUTOPLAY_ENABLE);