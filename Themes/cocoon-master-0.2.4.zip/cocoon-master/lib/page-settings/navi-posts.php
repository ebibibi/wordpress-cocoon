<?php //グローバルナビ設定をデータベースに保存

//グローバルナビ背景色
update_theme_option(OP_GLOBAL_NAVI_BACKGROUND_COLOR);

//グローバルナビ文字色
update_theme_option(OP_GLOBAL_NAVI_TEXT_COLOR);

// //グローバルナビホバー背景色
// update_theme_option(OP_GLOBAL_NAVI_HOVER_BACKGROUND_COLOR);

//グローバルナビメニュー幅
update_theme_option(OP_GLOBAL_NAVI_MENU_WIDTH);

//グローバルナビサブメニュー幅
update_theme_option(OP_GLOBAL_NAVI_SUB_MENU_WIDTH);

//グローバルナビメニューの固定
update_theme_option(OP_GLOBAL_NAVI_FIXED);
