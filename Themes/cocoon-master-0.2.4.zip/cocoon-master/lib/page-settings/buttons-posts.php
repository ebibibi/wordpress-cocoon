<?php //ボタン設定をデータベースに保存

//トップへ戻るボタンの表示
update_theme_option(OP_GO_TO_TOP_BUTTON_VISIBLE);

//トップへ戻るボタンのアイコンフォント
update_theme_option(OP_GO_TO_TOP_BUTTON_ICON_FONT);

//トップへ戻るボタンの画像
update_theme_option(OP_GO_TO_TOP_BUTTON_IMAGE_URL);

//ボタン背景色
update_theme_option(OP_GO_TO_TOP_BACKGROUND_COLOR);

//ボタン文字色
update_theme_option(OP_GO_TO_TOP_TEXT_COLOR);