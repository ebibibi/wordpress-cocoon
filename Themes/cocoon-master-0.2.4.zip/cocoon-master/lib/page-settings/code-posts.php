<?php //アクセス解析設定をデータベースに保存

//ソースコードをハイライト表示するか
update_theme_option(OP_CODE_HIGHLIGHT_ENABLE);
//ソースコードのハイライトスタイル
update_theme_option(OP_CODE_HIGHLIGHT_STYLE);
//ソースコードをハイライト表示するCSSセレクタ
update_theme_option(OP_CODE_HIGHLIGHT_CSS_SELECTOR);