<?php //インデックス設定をデータベースに保存
//エントリーカードタイプ
update_theme_option(OP_ENTRY_CARD_TYPE);

//エントリーカード枠線の表示
update_theme_option(OP_ENTRY_CARD_BORDER_VISIBLE);

//エントリーカード抜粋文の最大文字数
update_theme_option(OP_ENTRY_CARD_EXCERPT_MAX_LENGTH);