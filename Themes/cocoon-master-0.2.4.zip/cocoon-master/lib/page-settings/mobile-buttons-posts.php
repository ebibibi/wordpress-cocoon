<?php //モバイルボタン設定をデータベースに保存

//モバイルボタンレイアウト
update_theme_option(OP_MOBILE_BUTTON_LAYOUT_TYPE);