<?php //その他設定をデータベースに保存

//簡単SSL対応
update_theme_option(OP_EASY_SSL_ENABLE);